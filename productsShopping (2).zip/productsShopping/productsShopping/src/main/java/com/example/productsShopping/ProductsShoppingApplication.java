package com.example.productsShopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsShoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsShoppingApplication.class, args);
	}

}

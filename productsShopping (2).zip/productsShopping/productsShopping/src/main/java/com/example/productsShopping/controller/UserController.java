package com.example.productsShopping.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productsShopping.service.UserService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class UserController {
	private final UserService userService;

	@GetMapping("/profile")
	public ResponseEntity<?> getUserProfile(Principal principal) {
		if (principal == null) {
			// Return a clear response if the user is not authenticated
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("error", "User is not authenticated");
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
		}

		// If the user is authenticated, return their profile
		return ResponseEntity.ok(userService.getUserProfile(principal.getName()));
	}
}

package com.example.productsShopping.security;

import java.io.IOException;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; // Used for creating authentication.
import org.springframework.security.core.context.SecurityContextHolder; // Security context for storing authentication information.
import org.springframework.security.core.userdetails.UserDetails; // Interface for user data.
import org.springframework.security.core.userdetails.UserDetailsService; // Service for loading user data.
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource; // Source for creating authentication details.
import org.springframework.stereotype.Component; // Indicates that this is a Spring component.
import org.springframework.util.StringUtils; // Utility methods for working with strings.
import org.springframework.web.filter.OncePerRequestFilter; // A filter that executes only once per request.

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor; // Automatically generates a constructor for final fields.

@Component // Marks the class as a Spring component.
@RequiredArgsConstructor // Generates a constructor for all final fields.
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	private final JwtTokenProvider jwtTokenProvider; // Provider for working with JWT.
	private final UserDetailsService userDetailsService; // Service for retrieving user information.

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
			// Extracting the token from the request.
			String jwt = getJwtFromRequest(request);

			// Checking that the token exists and is valid.
			if (StringUtils.hasText(jwt) && jwtTokenProvider.validateToken(jwt)) {
				String username = jwtTokenProvider.getUsernameFromJWT(jwt); // Retrieving the username from the token.

				// Loading user information.
				UserDetails userDetails = userDetailsService.loadUserByUsername(username);

				// Creating an authentication object.
				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());

				// Adding request details to the authentication object.
				authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

				// Setting the authentication in the security context.
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
		} catch (Exception ex) {
			logger.error("Could not set user authentication in security context", ex); // Logging errors.
		}

		// Continuing the filter chain.
		filterChain.doFilter(request, response);
	}

	// Extracting JWT from the "Authorization" header.
	private String getJwtFromRequest(HttpServletRequest request) {
		String bearerToken = request.getHeader("Authorization"); // Reading the header.
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7); // Removing the "Bearer " prefix and returning the token.
		}
		return null; // Returning null if the token is missing or invalid.
	}
}

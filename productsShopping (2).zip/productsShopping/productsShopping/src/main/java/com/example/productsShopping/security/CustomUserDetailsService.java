package com.example.productsShopping.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.productsShopping.entity.User;
import com.example.productsShopping.repository.UserRepository;

import lombok.RequiredArgsConstructor;

// Remove the alias and use the full class name where necessary
@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {
	private final UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Search for the user in the database
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

		// Create UserDetails using the full class path
		return org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
				.password(user.getPassword()).authorities("USER").accountExpired(false).accountLocked(false)
				.credentialsExpired(false).disabled(false).build();
	}
}

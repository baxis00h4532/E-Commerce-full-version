package com.example.productsShopping.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productsShopping.dto.LoginRequest;
import com.example.productsShopping.dto.RegisterRequest;
import com.example.productsShopping.service.AuthService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
	private final AuthService authService;

	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@Valid @RequestBody RegisterRequest registerRequest) {
		try {
			// Attempt to register a user
			String responseMessage = authService.registerUser(registerRequest);
			return ResponseEntity.ok(responseMessage);
		} catch (RuntimeException ex) {
			// Return an error with the exception message
			return ResponseEntity.status(400).body(ex.getMessage());
		}
	}

	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@Valid @RequestBody LoginRequest loginRequest) {
		try {
			// Attempt to authenticate the user
			String token = authService.loginUser(loginRequest);
			return ResponseEntity.ok(token);
		} catch (RuntimeException ex) {
			// Return an error with the exception message
			return ResponseEntity.status(400).body(ex.getMessage());
		}
	}

	@PostMapping("/logout")
	public ResponseEntity<?> logoutUser() {
		try {
			// Call the logout method in the service (if server-side logic is implemented)
			authService.logoutUser();

			// Send a success response to the client
			return ResponseEntity.ok("Logout successful!");
		} catch (RuntimeException ex) {
			// Handle the exception
			return ResponseEntity.status(400).body(ex.getMessage());
		}
	}
}

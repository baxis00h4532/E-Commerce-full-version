package com.example.productsShopping.security;

import java.security.Key;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;

@Component // Makes the class available as a Spring component.
@RequiredArgsConstructor // Generates a constructor for all final fields.
public class JwtTokenProvider {

	@Value("${jwt.secret}") // Secret key from application.properties.
	private String jwtSecret;

	@Value("${jwt.expiration}") // Token expiration time from application.properties.
	private int jwtExpirationInMs;

	// Get the key for signing the JWT.
	private Key getSigningKey() {
		return Keys.hmacShaKeyFor(jwtSecret.getBytes());
	}

	// Generate a JWT token.
	public String generateToken(Authentication authentication) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal(); // Retrieve user details.
		Date now = new Date(); // Current date.
		Date expiryDate = new Date(now.getTime() + jwtExpirationInMs); // Token expiration date.

		// Create and return the token.
		return Jwts.builder().setSubject(userDetails.getUsername()) // Set the username.
				.setIssuedAt(now) // Set the token creation date.
				.setExpiration(expiryDate) // Set the token expiration date.
				.signWith(getSigningKey(), SignatureAlgorithm.HS512) // Sign the token.
				.compact();
	}

	// Extract the username from the token.
	public String getUsernameFromJWT(String token) {
		Claims claims = Jwts.parserBuilder().setSigningKey(getSigningKey()) // Set the key for signature verification.
				.build().parseClaimsJws(token) // Parse the token.
				.getBody(); // Extract the claims from the token.
		return claims.getSubject(); // Return the username.
	}

	// Validate the token.
	public boolean validateToken(String authToken) {
		try {
			Jwts.parserBuilder().setSigningKey(getSigningKey()) // Set the key for signature verification.
					.build().parseClaimsJws(authToken); // Verify the token.
			return true; // The token is valid.
		} catch (SecurityException ex) {
			// Invalid token signature.
		} catch (MalformedJwtException ex) {
			// Invalid token format.
		} catch (ExpiredJwtException ex) {
			// The token is expired.
		} catch (UnsupportedJwtException ex) {
			// The token is unsupported.
		} catch (IllegalArgumentException ex) {
			// The token is an empty string.
		}
		return false; // The token is not valid.
	}
}

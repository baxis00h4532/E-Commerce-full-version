package com.example.productsShopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsShoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
